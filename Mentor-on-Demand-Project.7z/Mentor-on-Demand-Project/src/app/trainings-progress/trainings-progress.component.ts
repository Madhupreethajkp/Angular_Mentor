import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trainings-progress',
  templateUrl: './trainings-progress.component.html',
  styleUrls: ['./trainings-progress.component.css']
})
export class TrainingsProgressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
