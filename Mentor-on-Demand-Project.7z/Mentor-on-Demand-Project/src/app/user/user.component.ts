import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  user1: User
 
  password:string;
  username:string;


  constructor(private userService: UserService) { }

  

  ngOnInit() {
  }
 
  onSubmit() {
    
    console.log("save")
    this.userService.searchUser(this.username,this.password).subscribe(
      (user:User)=>{
        console.log(user)
        this.createUser(user)
      }
    );
     
    
  }

  createUser(user:User){
    this.user1=user
    window.localStorage.setItem("user",this.user1.username);
  }
}
