import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainings } from '../trainings';
import { TrainingService } from '../training.service';

@Component({
  selector: 'app-mentor-trainings',
  templateUrl: './mentor-trainings.component.html',
  styleUrls: ['./mentor-trainings.component.css']
})
export class MentorTrainingsComponent implements OnInit {

  trainings: Observable<Trainings[]>;
  
  mentorName:string;
  constructor(private techService: TrainingService) { }

  
  
 mentor : string=window.localStorage.getItem("mentor");

  ngOnInit() {
    this.trainings=this.techService.getMentorTrainings(this.mentor);
  }

  onSubmit(technologies:Trainings)
  {
    this.techService.acceptTraining(technologies).subscribe((data:Trainings) => {console.log(data), error => console.log(error)});;
  }

}
