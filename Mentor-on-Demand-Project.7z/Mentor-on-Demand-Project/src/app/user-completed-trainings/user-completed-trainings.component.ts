import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainings } from '../trainings';
import { TrainingService } from '../training.service';

@Component({
  selector: 'app-user-completed-trainings',
  templateUrl: './user-completed-trainings.component.html',
  styleUrls: ['./user-completed-trainings.component.css']
})
export class UserCompletedTrainingsComponent implements OnInit {

  trainings: Observable<Trainings[]>;

  constructor(private techService: TrainingService) { }

  
  
 user : string=window.localStorage.getItem("user");

  ngOnInit() {
    this.trainings=this.techService.getMyCompletedTrainings(this.user);
  }


}
