import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstpageComponent } from './firstpage/firstpage.component';
import { UserComponent } from './user/user.component';

import { UserRegisterComponent } from './user-register/user-register.component';
import { HttpClientModule } from '@angular/common/http';
import { MentorComponent } from './mentor/mentor.component';
import { HeaderComponent } from './header/header.component';
import { UserLandingPageComponent } from './user-landing-page/user-landing-page.component';
import { SearchedTechnologiesComponent } from './searched-technologies/searched-technologies.component';
import { CoursesComponent } from './courses/courses.component';
import { UserTrainingsComponent } from './user-trainings/user-trainings.component';
import { UserCompletedTrainingsComponent } from './user-completed-trainings/user-completed-trainings.component';
import { UserProposedTrainingsComponent } from './user-proposed-trainings/user-proposed-trainings.component';
import { MentorRegisterComponent } from './mentor-register/mentor-register.component';
import { AdminComponent } from './admin/admin.component';
import { MentorLandingPageComponent } from './mentor-landing-page/mentor-landing-page.component';
import { MentorTrainingsComponent } from './mentor-trainings/mentor-trainings.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';
import { TrainingsProgressComponent } from './trainings-progress/trainings-progress.component';


@NgModule({
  declarations: [
    AppComponent,
    FirstpageComponent,
    UserComponent,
    UserRegisterComponent,
    MentorComponent,
    HeaderComponent,
    UserLandingPageComponent,
    SearchedTechnologiesComponent,
    CoursesComponent,
    UserTrainingsComponent,
    UserCompletedTrainingsComponent,
    UserProposedTrainingsComponent,
    MentorRegisterComponent,
    AdminComponent,
    MentorLandingPageComponent,
    MentorTrainingsComponent,
    MentorProfileComponent,
    MentorPaymentComponent,
    TrainingsProgressComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
