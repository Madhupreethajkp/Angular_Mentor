import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Mentor } from './mentor';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  private baseUrl = 'http://localhost:8976/mentor';

  constructor(private http: HttpClient) { } 

  //searchUser(username: string,password :string): Observable<any> {
    //console.log(username)
    //return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
 // }

  createMentor(mentor: Mentor): Observable<Mentor> {
    return this.http.post<Mentor>(`${this.baseUrl}/create`, mentor);
  }

  searchMentor(username: string,password :string): Observable<any> {
    console.log(username)
    return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
  }

  getMentorProfile(mentor: string): Observable<any> {
    console.log(mentor);
    return this.http.get<Mentor>(`${this.baseUrl}/fetchMentorProfile/${mentor}`);
  }
}
