import { Component, OnInit } from '@angular/core';
import { MentorService } from '../mentor.service';
import { Mentor } from '../mentor';

@Component({
  selector: 'app-mentor',
  templateUrl: './mentor.component.html',
  styleUrls: ['./mentor.component.css']
})
export class MentorComponent implements OnInit {

  constructor(private mentorService:MentorService) { }

  mentor1: Mentor
 
  password:string;
  username:string;

  ngOnInit() {
  }
  onSubmit() {
    
    console.log("save")
    this.mentorService.searchMentor(this.username,this.password).subscribe(
      (mentor:Mentor)=>{
        console.log(mentor)
        this.createMentor(mentor)
      }
    );
     
    
  }

  createMentor(mentor:Mentor){
    this.mentor1=mentor 
    window.localStorage.setItem("mentor",this.mentor1.username);
  }

}
