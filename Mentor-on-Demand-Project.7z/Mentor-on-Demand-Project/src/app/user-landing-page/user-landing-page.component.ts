import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../training.service';
import { Technologies } from '../technologies';
import { Observable } from 'rxjs';
import { AppRoutingModule } from '../app-routing.module';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-landing-page',
  templateUrl: './user-landing-page.component.html',
  styleUrls: ['./user-landing-page.component.css']
})
export class UserLandingPageComponent implements OnInit {

  constructor(private techService: TrainingService,private route:Router) { }

  technologies1: Observable<Technologies[]>;
  
  
  ngOnInit() {
    
  }
  courses()
  {
    this.route.navigate(['course']); }

  trainings()
  {
    this.route.navigate(['trainings'])
  }
  proposedTrainings(){
    this.route.navigate(['proposedTrainings'])
  }

  completedTrainings()
  {
    this.route.navigate(['completedTrainings'])}

}
