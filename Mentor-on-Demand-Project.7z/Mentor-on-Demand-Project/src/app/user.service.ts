import { Injectable, ɵConsole } from '@angular/core';

import { Observable } from 'rxjs';
import { HttpClient} from '@angular/common/http';
import { User } from './user';
import { Technologies } from './technologies';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  getCoarses(): Observable<Technologies> {
    throw new Error("Method not implemented.");
  }
 

  private baseUrl = 'http://localhost:8976/api1';

  constructor(private http: HttpClient) { }

  //searchUser(username: string,password :string): Observable<any> {
    //console.log(username)
    //return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
 // }

  createUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.baseUrl}/create`, user);
  }

  sample():Observable<any>{
    return this.http.get(`${this.baseUrl}/sample`)
  }
  searchTechnologies(name: string,start_time :string): Observable<any> {
    return this.http.get(`${this.baseUrl}/search/${name}/${start_time}`);
  }
  searchUser(username: string,password :string): Observable<any> {
    console.log(username)
    return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
  }

  
}
