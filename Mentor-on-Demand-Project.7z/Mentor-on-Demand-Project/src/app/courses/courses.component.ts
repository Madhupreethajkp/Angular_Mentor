import { Component, OnInit } from '@angular/core';

import { Technologies } from '../technologies';
import { Observable } from 'rxjs';
import { TrainingService } from '../training.service';
import { TechnologiesService } from '../technologies.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {

 

  technologies1: Observable<Technologies[]>;
  mentorName:Observable<string>;

  constructor(private techService: TrainingService,private tech1:TechnologiesService) { }

  
  
 user : string=window.localStorage.getItem("user");

  ngOnInit() {
    this.technologies1=this.techService.getCoarses();
  }

  onSubmit(technology:Technologies)
  {
    
    this.techService.createTraining(technology,this.user)
    .subscribe((data:Technologies) => {console.log(data), error => console.log(error)});
}
 
 
    
    
   
     
    
  
}
