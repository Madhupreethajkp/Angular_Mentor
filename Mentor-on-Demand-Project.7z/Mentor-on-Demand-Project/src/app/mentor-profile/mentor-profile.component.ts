import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { Observable } from 'rxjs';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-profile',
  templateUrl: './mentor-profile.component.html',
  styleUrls: ['./mentor-profile.component.css']
})
export class MentorProfileComponent implements OnInit {

  mentor1: Mentor;
  show:boolean=false
  
  constructor(private mentorService: MentorService) { }

  
  
 mentor : string=window.localStorage.getItem("mentor");

  ngOnInit() {
    this.mentorService.getMentorProfile(this.mentor).subscribe(
      (mentor:Mentor)=>{
        this.mentorCreate(mentor)
      }
    );
  }

  mentorCreate(mentor:Mentor){
    this.mentor1=mentor
    this.show=true
  }

}
