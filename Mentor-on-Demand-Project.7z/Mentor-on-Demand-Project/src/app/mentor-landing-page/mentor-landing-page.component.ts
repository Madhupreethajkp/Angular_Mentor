import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mentor-landing-page',
  templateUrl: './mentor-landing-page.component.html',
  styleUrls: ['./mentor-landing-page.component.css']
})
export class MentorLandingPageComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {

  }
  requested()
  {
    this.route.navigate(['mentorTrainings'])
  }

  profile()
  {
    this.route.navigate(['mentorProfile'])
  }
  payment()
  {
    this.route.navigate(['mentorPayment'])
  }
  progress()
  {
    this.route.navigate(['trainingsProgress'])
  }
}
