import { Component, OnInit } from '@angular/core';
import { Mentor } from '../mentor';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-register',
  templateUrl: './mentor-register.component.html',
  styleUrls: ['./mentor-register.component.css']
})
export class MentorRegisterComponent implements OnInit {

  mentor: Mentor = new Mentor();
  submitted = false;

  constructor(private mentorService: MentorService) { }

  ngOnInit() {
   
  }

  newMentor(): void {
    this.submitted = false;
    this.mentor = new Mentor();
  }

  save() {
    console.log("save")
    this.mentorService.createMentor(this.mentor)
      .subscribe((data:Mentor) => {console.log(data), error => console.log(error)});
    this.mentor = new Mentor();
  }
  onSubmit() {
    
    this.submitted = true;
    this.save();
  }

}
