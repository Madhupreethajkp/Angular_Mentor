import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { UserRegisterComponent } from './user-register/user-register.component';
import { FirstpageComponent } from './firstpage/firstpage.component';
import { UserLandingPageComponent } from './user-landing-page/user-landing-page.component';
import { SearchedTechnologiesComponent } from './searched-technologies/searched-technologies.component';

import { UserTrainingsComponent } from './user-trainings/user-trainings.component';
import { UserCompletedTrainingsComponent } from './user-completed-trainings/user-completed-trainings.component';
import { UserProposedTrainingsComponent } from './user-proposed-trainings/user-proposed-trainings.component';
import { CoursesComponent } from './courses/courses.component';
import { MentorComponent } from './mentor/mentor.component';
import { MentorRegisterComponent } from './mentor-register/mentor-register.component';
import { AdminComponent } from './admin/admin.component';
import { MentorLandingPageComponent } from './mentor-landing-page/mentor-landing-page.component';
import { MentorProfileComponent } from './mentor-profile/mentor-profile.component';
import { TrainingsProgressComponent } from './trainings-progress/trainings-progress.component';
import { MentorTrainingsComponent } from './mentor-trainings/mentor-trainings.component';
import { MentorPaymentComponent } from './mentor-payment/mentor-payment.component';

const routes: Routes = [
  { path: 'user', component: UserComponent },
  { path :'user/userSignup' , component: UserRegisterComponent},
  { path :'getStarted' , component: FirstpageComponent},
  {path:'user/userLanding',component :UserLandingPageComponent},
  {path:'course',component :CoursesComponent},
  {path:'trainings',component :UserTrainingsComponent},
  {path:'completedTrainings',component :UserCompletedTrainingsComponent},
  {path:'proposedTrainings',component :UserProposedTrainingsComponent},
  {path:'mentor',component :MentorComponent},
  {path:'mentor/mentorSignup',component :MentorRegisterComponent},
  {path:'admin',component :AdminComponent},
  {path:'mentor/mentorLanding',component :MentorLandingPageComponent},
  {path:'mentorProfile',component :MentorProfileComponent},
  {path:'trainingsProgress',component :TrainingsProgressComponent},
 {path:'mentorTrainings',component :MentorTrainingsComponent},
 {path:'mentorPayment',component :MentorPaymentComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
