export class Mentor {

    
    id:number
  contact_number:string;
    firstname:string;
    lastname:string;
    password:string;
    reg_code:string;
    
    username:string;
    linkedin_url:string;
    reg_datetime:Date;
    years_of_experience:number
    active:string

}
