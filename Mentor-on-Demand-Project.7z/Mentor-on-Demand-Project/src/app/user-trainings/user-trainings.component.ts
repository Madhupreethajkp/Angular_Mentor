import { Component, OnInit } from '@angular/core';
import { TrainingService } from '../training.service';
import { Trainings } from '../trainings';
import { Observable } from 'rxjs';
import { Technologies } from '../technologies';

@Component({
  selector: 'app-user-trainings',
  templateUrl: './user-trainings.component.html',
  styleUrls: ['./user-trainings.component.css']
})
export class UserTrainingsComponent implements OnInit {

  

  

  trainings: Observable<Trainings[]>;
  currentTraining:Trainings
  mentorName:string;
  constructor(private techService: TrainingService) { }

  
  
 user : string=window.localStorage.getItem("user");

  ngOnInit() {
    this.trainings=this.techService.getMyTrainings(this.user);
  }

  
  

}
