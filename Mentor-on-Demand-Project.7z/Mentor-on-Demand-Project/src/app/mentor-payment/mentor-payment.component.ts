import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-payment',
  templateUrl: './mentor-payment.component.html',
  styleUrls: ['./mentor-payment.component.css']
})
export class MentorPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
