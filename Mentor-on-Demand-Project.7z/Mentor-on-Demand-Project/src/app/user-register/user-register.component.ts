import { Component, OnInit } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-register',
  templateUrl: './user-register.component.html',
  styleUrls: ['./user-register.component.css']
})
export class UserRegisterComponent implements OnInit {

  user: User = new User();
  submitted = false;

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.sample().subscribe(
      (a:number)=>{
        console.log(a)
      }
    )
  }

  newUser(): void {
    this.submitted = false;
    this.user = new User();
  }

  save() {
    console.log("save")
    this.userService.createUser(this.user)
      .subscribe((data:User) => {console.log(data), error => console.log(error)});
    this.user = new User();
  }
  onSubmit() {
    
    this.submitted = true;
    this.save();
  }
}


