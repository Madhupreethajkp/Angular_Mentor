import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchedTechnologiesComponent } from './searched-technologies.component';

describe('SearchedTechnologiesComponent', () => {
  let component: SearchedTechnologiesComponent;
  let fixture: ComponentFixture<SearchedTechnologiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchedTechnologiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchedTechnologiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
