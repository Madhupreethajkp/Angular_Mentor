import { Component, OnInit, Input } from '@angular/core';
import { Technologies } from '../technologies';
import { HeaderComponent } from '../header/header.component';
import { UserService } from '../user.service';
import { TrainingService } from '../training.service';

@Component({
  selector: 'app-searched-technologies',
  templateUrl: './searched-technologies.component.html',
  styleUrls: ['./searched-technologies.component.css']
})
export class SearchedTechnologiesComponent implements OnInit {

 
  @Input() technologies: Technologies;
  
  ngOnInit() {
  }

  constructor(private trainingService: TrainingService) { }
  
 user : string=window.localStorage.getItem("user");

  onSubmit()
  {
    this.trainingService.createTraining(this.technologies,this.user)
    .subscribe((data:Technologies) => {console.log(data), error => console.log(error)});
}
}
