import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Technologies } from './technologies';
import { Observable } from 'rxjs';
import { Trainings } from './trainings';

@Injectable({
  providedIn: 'root'
})
export class TrainingService {
  
  

  private baseUrl = 'http://localhost:8976/api';

  constructor(private http: HttpClient) { }


  createTraining(technologies2: Technologies,user:string){
    return this.http.post<Technologies>(`${this.baseUrl}/training/create/${user}`, technologies2);
  }

  getCoarses():Observable<any>{
    
    return this.http.get<Technologies[]>(`${this.baseUrl}/allTrainings`);
  }
  getMyTrainings(user: string): Observable<any> {
    return this.http.get<Trainings>(`${this.baseUrl}/training/fetch/${user}`);
  }
  getMyProposedTrainings(user: string): Observable<any> {
    return this.http.get<Trainings>(`${this.baseUrl}/training/fetchProposed/${user}`);
  }
  getMyCompletedTrainings(user: string): Observable<any> {
    return this.http.get<Trainings>(`${this.baseUrl}/training/fetchCompleted/${user}`);
  }
  createTraining1(technologies2: Technologies,user:string,mentorName:Observable<string>){
    return this.http.post<Technologies>(`${this.baseUrl}/create/${user}/${mentorName}`, technologies2);
  }
  getMentorTrainings(mentor: string): Observable<any> {
    return this.http.get<Trainings>(`${this.baseUrl}/training/fetchMentor/${mentor}`);
  }
  acceptTraining(training:Trainings)
  {
    return this.http.post<Trainings>(`${this.baseUrl}/acceptTraining`, training);
  }


}
