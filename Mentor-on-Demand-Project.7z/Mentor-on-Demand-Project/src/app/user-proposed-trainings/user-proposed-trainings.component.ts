import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainings } from '../trainings';
import { TrainingService } from '../training.service';

@Component({
  selector: 'app-user-proposed-trainings',
  templateUrl: './user-proposed-trainings.component.html',
  styleUrls: ['./user-proposed-trainings.component.css']
})
export class UserProposedTrainingsComponent implements OnInit {

  
  trainings: Observable<Trainings[]>;

  constructor(private techService: TrainingService) { }

  
  
 user : string=window.localStorage.getItem("user");

  ngOnInit() {
    this.trainings=this.techService.getMyProposedTrainings(this.user);
  }

  

}
