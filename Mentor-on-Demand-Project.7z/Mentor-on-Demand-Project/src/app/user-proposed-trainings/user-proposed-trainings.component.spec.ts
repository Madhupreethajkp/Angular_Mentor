import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserProposedTrainingsComponent } from './user-proposed-trainings.component';

describe('UserProposedTrainingsComponent', () => {
  let component: UserProposedTrainingsComponent;
  let fixture: ComponentFixture<UserProposedTrainingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserProposedTrainingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserProposedTrainingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
