import { Technologies } from './technologies';

describe('Technologies', () => {
  it('should create an instance', () => {
    expect(new Technologies()).toBeTruthy();
  });
});
