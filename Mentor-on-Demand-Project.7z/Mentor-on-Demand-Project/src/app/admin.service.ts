import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseUrl = 'http://localhost:8976/admin';

  constructor(private http: HttpClient) { }

  //searchUser(username: string,password :string): Observable<any> {
    //console.log(username)
    //return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
 // }

  

  searchAdmin(username: string,password :string): Observable<any> {
    console.log(username)
    return this.http.get(`${this.baseUrl}/login/${username}/${password}`);
  }
}
