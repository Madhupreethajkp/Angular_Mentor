import { Component, OnInit } from '@angular/core';
import { Technologies } from '../technologies';
import { UserService } from '../user.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  technologies1: Observable<Technologies[]>;
  technologies: Technologies = new Technologies();
  start_time:string;
  name:string;


  constructor(private userService: UserService) { }

  

  ngOnInit() {
  }
 
  onSubmit() {
    
    console.log("save")
   this.technologies1= this.userService.searchTechnologies(this.name,this.start_time);
     
    
  }

  

}
