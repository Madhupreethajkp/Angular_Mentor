import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Technologies } from './technologies';
import { Observable } from 'rxjs';
import { Trainings } from './trainings';

@Injectable({
  providedIn: 'root'
})
export class TechnologiesService {

 
  private baseUrl = 'http://localhost:8976/tech';

  constructor(private http: HttpClient) { }


  fetchMentor(technologies2: Technologies):Observable<any>{
    return this.http.post<Technologies>(`${this.baseUrl}/fetchMentor`, technologies2);
  }

  

}
