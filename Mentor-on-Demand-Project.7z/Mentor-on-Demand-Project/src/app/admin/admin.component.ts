import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Admin } from '../admin';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private adminService:AdminService) { }

  admin1: Admin
 
  password:string;
  username:string;

  ngOnInit() {
  }
  onSubmit() {
    
    console.log("save")
    this.adminService.searchAdmin(this.username,this.password).subscribe(
      (admin:Admin)=>{
        console.log(admin)
        this.createUser(admin)
      }
    );
     
    
  }

  createUser(admin:Admin){
    this.admin1=admin
    window.localStorage.setItem("mentor",this.admin1.username);
  }


}
